package com.example.demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "employee")
public class Employee {
	@Id
	@Column(name = "empId")
	int id;
	@Column(name = "lastName")
	String lastName;
	@Column(name = "firstName")
	String firstName;
	@Column(name = "salary")
	int salary;

	public Employee(int id, String lastName, String firstName, int salary) {
		super();
		this.id = id;
		this.lastName = lastName;
		this.firstName = firstName;
		this.salary = salary;
	}

	public Employee() {
		super();
	}

	
}
