package com.example.demo;

import javax.security.auth.login.Configuration;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class HibernateUtil {
	public static void main(String[] args) {
		StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
		
		Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();
		
		SessionFactory factory = meta.getSessionFactoryBuilder().build();
		
		// Initialize session object
		Session session = factory.openSession();
		
		Employee employee = new Employee(110,"Kumar V","Ranjith",30000);
		session.beginTransaction();
		session.save(employee);
		session.getTransaction().commit();
		session.close();
		
		System.out.println("Data Saved!!!");
		
	}
}
